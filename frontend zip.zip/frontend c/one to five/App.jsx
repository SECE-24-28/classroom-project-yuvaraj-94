import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Auth } from './pages/Auth';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Recharge } from './pages/Recharge';
import { History } from './pages/History';
import { Admin } from './pages/Admin';

const ProtectedRoute = ({ children }) => {
   const user = localStorage.getItem('volt_user');
   if (!user) {
      return <Navigate to="/landing" replace />;
   }
   return <>{children}</>;
};

const AdminRoute = ({ children }) => {
   const userString = localStorage.getItem('volt_user');
   if (!userString) return <Navigate to="/landing" replace />;
   try {
      const user = JSON.parse(userString);
      if (user.role !== 'admin') return <Navigate to="/" replace />;
   } catch {
      return <Navigate to="/landing" replace />;
   }
   return <>{children}</>;
};

const Layout = ({ children }) => {
   return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-rose-50 flex flex-col">
         <Navbar />
         <main className="flex-grow">
            {children}
         </main>
         <footer className="bg-white border-t border-gray-200 py-8">
            <div className="max-w-7xl mx-auto px-4">
               <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                  <div>
                     <h3 className="font-bold text-gray-900 mb-4">About</h3>
                     <ul className="space-y-2 text-gray-600 text-sm">
                        <li><a href="#" className="hover:text-yellow-600 transition">About Us</a></li>
                        <li><a href="#" className="hover:text-yellow-600 transition">Blog</a></li>
                        <li><a href="#" className="hover:text-yellow-600 transition">Careers</a></li>
                     </ul>
                  </div>
                  <div>
                     <h3 className="font-bold text-gray-900 mb-4">Support</h3>
                     <ul className="space-y-2 text-gray-600 text-sm">
                        <li><a href="#" className="hover:text-yellow-600 transition">Help Center</a></li>
                        <li><a href="#" className="hover:text-yellow-600 transition">Contact Us</a></li>
                        <li><a href="#" className="hover:text-yellow-600 transition">FAQ</a></li>
                     </ul>
                  </div>
                  <div>
                     <h3 className="font-bold text-gray-900 mb-4">Legal</h3>
                     <ul className="space-y-2 text-gray-600 text-sm">
                        <li><a href="#" className="hover:text-yellow-600 transition">Privacy</a></li>
                        <li><a href="#" className="hover:text-yellow-600 transition">Terms</a></li>
                        <li><a href="#" className="hover:text-yellow-600 transition">Security</a></li>
                     </ul>
                  </div>
               </div>
               <div className="border-t border-gray-200 pt-8 text-center text-gray-500 text-sm">
                  © 2024 Mobi-Charge. All rights reserved. ⚡
               </div>
            </div>
         </footer>
      </div>
   );
}

function App() {
  return (
    <Router>
       <Routes>
         <Route path="/landing" element={<Landing />} />
         <Route path="/login" element={<Login />} />
         <Route path="/register" element={<Register />} />
         <Route path="/auth" element={<Auth />} />
         
         <Route path="/" element={
           <ProtectedRoute>
             <Layout>
               <Recharge />
             </Layout>
           </ProtectedRoute>
         } />
         
         <Route path="/admin" element={
           <AdminRoute>
             <Layout>
               <Admin />
             </Layout>
           </AdminRoute>
         } />
         
         <Route path="/history" element={
           <ProtectedRoute>
             <Layout>
               <History />
             </Layout>
           </ProtectedRoute>
         } />

         <Route path="*" element={<Navigate to="/landing" replace />} />
       </Routes>
    </Router>
  );
}

export default App;
