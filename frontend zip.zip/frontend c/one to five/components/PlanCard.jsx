import React, { useState } from 'react';
import { Wifi, Clock, Info, Zap, ArrowRight } from 'lucide-react';

export const PlanCard = ({ plan, onSelect }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="relative group h-full overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-gray-50 group-hover:from-yellow-50 group-hover:via-white group-hover:to-orange-50 transition-all duration-300"></div>
      
      <div className={`absolute inset-0 rounded-2xl transition-all duration-300 ${isHovered ? 'bg-gradient-to-r from-yellow-400/30 to-orange-400/30' : 'bg-gradient-to-r from-gray-200/30 to-gray-200/30'}`}></div>
      
      <div className="relative bg-white rounded-2xl shadow-lg border border-gray-100 hover:border-yellow-400/50 hover:shadow-2xl hover:shadow-yellow-400/20 transition-all duration-300 p-6 flex flex-col h-full transform hover:scale-105">
        
        <div className="absolute top-4 right-4 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 text-yellow-700 text-xs px-3 py-1.5 rounded-full font-bold border border-yellow-200">
          {plan.operator}
        </div>

        <div className="mb-6 pt-2">
          <div className="flex items-baseline gap-1 mb-2">
            <span className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">₹{plan.price}</span>
            {plan.type === 'Data' && <Zap className="h-5 w-5 text-yellow-500 animate-pulse" />}
          </div>
          <span className="inline-block bg-gradient-to-r from-yellow-100 to-orange-100 text-yellow-700 text-xs font-bold px-3 py-1 rounded-full border border-yellow-200">
            {plan.type}
          </span>
        </div>

        <div className="space-y-4 flex-grow">
          <div className="flex items-center gap-3 p-3 bg-fuchsia-50/50 rounded-xl border border-fuchsia-100/50 hover:bg-fuchsia-50 transition-all">
            <div className="bg-fuchsia-100 p-2 rounded-lg flex-shrink-0">
              <Wifi className="h-4 w-4 text-fuchsia-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Data</p>
              <p className="font-bold text-gray-900">{plan.data}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-violet-50/50 rounded-xl border border-violet-100/50 hover:bg-violet-50 transition-all">
            <div className="bg-violet-100 p-2 rounded-lg flex-shrink-0">
              <Clock className="h-4 w-4 text-violet-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Validity</p>
              <p className="font-bold text-gray-900">{plan.validity}</p>
            </div>
          </div>

          <div className="flex gap-2 text-xs text-gray-600 bg-gray-50/50 p-3 rounded-xl border border-gray-100/50">
            <Info className="h-4 w-4 text-gray-400 flex-shrink-0 mt-0.5" />
            <p className="line-clamp-2">{plan.description}</p>
          </div>
        </div>

        <button
          onClick={() => onSelect(plan)}
          className="mt-6 w-full bg-gradient-to-r from-yellow-400 to-orange-400 text-black py-3 px-4 rounded-xl font-bold hover:shadow-lg hover:shadow-yellow-400/50 active:scale-95 transition-all focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 flex items-center justify-center gap-2 group/btn"
        >
          Select Plan
          <ArrowRight className={`h-4 w-4 transition-transform ${isHovered ? 'translate-x-1' : ''}`} />
        </button>
      </div>
    </div>
  );
};
