export const Operator = {
  AIRTEL: 'Airtel',
  JIO: 'Jio',
  VI: 'Vi',
  BSNL: 'BSNL'
};
