const product = {
    name: "Laptop",
    price: 55000,
    brand: "Dell"
};

// 👉 Export this object as default
export default product;
